# Deployment Guide

## Railway.app Deployment

1. Create GitHub repo
2. Upload all files
3. Go to railway.app
4. Deploy from GitHub
5. Add environment variables
6. Done!

See full guide at: https://railway.app/docs
